package com.kenzphone.kenzoslauncher;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ActivityManager;
import android.content.IntentFilter;
import android.app.WallpaperManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class MainActivity extends Activity {
    private final int BG = Color.rgb(9,10,13), PANEL = Color.rgb(22,24,30), RED = Color.rgb(255,52,52), MUTED = Color.rgb(157,163,176), WHITE = Color.WHITE;
    private LinearLayout root, content, nav;
    private String page = "HOME";

    @Override public void onCreate(Bundle b) { super.onCreate(b); getWindow().setStatusBarColor(BG); getWindow().setNavigationBarColor(BG); showPage("HOME"); }

    private GradientDrawable shape(int color, int radius) { GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d; }
    private int dp(float n) { return (int)(n * getResources().getDisplayMetrics().density + 0.5f); }
    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); t.setGravity(Gravity.CENTER_VERTICAL);
        if (bold) t.setTypeface(Typeface.create("sans-serif", Typeface.BOLD)); return t;
    }
    private LinearLayout column() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    private LinearLayout row() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); l.setGravity(Gravity.CENTER_VERTICAL); return l; }
    private void pad(View v, int l, int t, int r, int b) { v.setPadding(dp(l),dp(t),dp(r),dp(b)); }
    private void gap(LinearLayout l, int h) { View v = new View(this); l.addView(v, new LinearLayout.LayoutParams(1,dp(h))); }
    private void card(LinearLayout parent, View child) { child.setBackground(shape(PANEL,20)); pad(child,16,15,16,15); LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1,-2); p.bottomMargin=dp(12); parent.addView(child,p); }
    private Button button(String label) { Button b = new Button(this); b.setText(label); b.setTextColor(WHITE); b.setAllCaps(false); b.setTextSize(14); b.setBackground(shape(RED,14)); b.setPadding(dp(14),dp(8),dp(14),dp(8)); return b; }

    private void showPage(String p) {
        page=p; root=column(); root.setBackgroundColor(BG); setContentView(root);
        LinearLayout header=row(); pad(header,20,16,20,12);
        LinearLayout brand=column(); TextView logo=text("KENZOS",25,WHITE,true); TextView sub=text("GAMING SYSTEM  /  KENZPHONE",9,RED,true); brand.addView(logo); brand.addView(sub); header.addView(brand,new LinearLayout.LayoutParams(0,-2,1));
        TextView settings=text("⚙",25,WHITE,true); settings.setGravity(Gravity.CENTER); settings.setOnClickListener(v->startActivity(new Intent(Settings.ACTION_SETTINGS))); header.addView(settings,new LinearLayout.LayoutParams(dp(42),dp(42))); root.addView(header);
        ScrollView scroll=new ScrollView(this); scroll.setFillViewport(false); content=column(); pad(content,18,8,18,12); scroll.addView(content); root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        if ("HOME".equals(p)) home(); else if ("GAMES".equals(p)) games(); else tools();
        nav=row(); nav.setBackgroundColor(Color.rgb(14,15,20)); pad(nav,12,8,12,8);
        addNav("⌂\nHOME","HOME"); addNav("▣\nGAMES","GAMES"); addNav("✦\nTOOLS","TOOLS"); root.addView(nav,new LinearLayout.LayoutParams(-1,dp(64)));
    }
    private void addNav(String label, String target) { TextView t=text(label,11,target.equals(page)?RED:MUTED,true); t.setGravity(Gravity.CENTER); t.setOnClickListener(v->showPage(target)); nav.addView(t,new LinearLayout.LayoutParams(0,-1,1)); }

    private void home() {
        TextView hello=text("YOUR GAME. YOUR RULES.",12,MUTED,true); content.addView(hello); gap(content,12);
        LinearLayout hero=column(); hero.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{Color.rgb(61,17,24),Color.rgb(24,18,26),Color.rgb(17,19,25)})); hero.setCornerRadius(dp(24)); pad(hero,20,20,20,20);
        TextView tag=text("KENZOS  /  CORE INTERFACE",10,RED,true); hero.addView(tag); gap(hero,16);
        TextView title=text("GAME\nSPACE",34,WHITE,true); hero.addView(title); gap(hero,6);
        TextView desc=text("Semua game. Satu ruang.\nSiap untuk sesi bermain berikutnya.",13,MUTED,false); hero.addView(desc); gap(hero,20);
        Button open=button("BUKA GAME SPACE   →"); open.setOnClickListener(v->showPage("GAMES")); hero.addView(open,new LinearLayout.LayoutParams(-1,dp(50))); card(content,hero);
        TextView section=text("SYSTEM SNAPSHOT",12,WHITE,true); content.addView(section); gap(content,10);
        LinearLayout metrics=row(); metric(metrics,"MODE","BALANCED"); metric(metrics,"BATTERY",getBatteryPercent()+"%"); metric(metrics,"APPS",String.valueOf(Math.max(0,getLaunchableApps().size()-1))); content.addView(metrics); gap(content,14);
        LinearLayout memory=column(); memory.setBackground(shape(PANEL,16)); pad(memory,14,12,14,12); memory.addView(text("MEMORY SNAPSHOT",10,MUTED,true)); gap(memory,7); ActivityManager.MemoryInfo mi=new ActivityManager.MemoryInfo(); ((ActivityManager)getSystemService(ACTIVITY_SERVICE)).getMemoryInfo(mi); long used=Math.max(0,mi.totalMem-mi.availMem); int usedPct=mi.totalMem>0?(int)(used*100/mi.totalMem):0; memory.addView(text("RAM digunakan sekitar "+usedPct+"%",13,WHITE,true)); gap(memory,8); android.widget.ProgressBar ramBar=new android.widget.ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal); ramBar.setMax(100); ramBar.setProgress(usedPct); if(android.os.Build.VERSION.SDK_INT>=21) ramBar.setProgressTintList(android.content.res.ColorStateList.valueOf(RED)); memory.addView(ramBar,new LinearLayout.LayoutParams(-1,dp(5))); gap(content,2); card(content,memory); gap(content,8);
        LinearLayout quick=column(); TextView qtitle=text("QUICK ACCESS",12,WHITE,true); quick.addView(qtitle); gap(quick,10);
        String[][] items={{"🎮","Game Space"},{"⚡","Performance"},{"🎨","Themes"},{"🛠","Tools"}};
        for(int i=0;i<items.length;i+=2){ LinearLayout r=row(); for(int j=i;j<Math.min(i+2,items.length);j++){ final String name=items[j][1]; LinearLayout tile=column(); tile.setBackground(shape(PANEL,16)); pad(tile,14,14,14,14); tile.addView(text(items[j][0]+"   "+name,14,WHITE,true)); tile.setOnClickListener(v->{if(name.equals("Game Space"))showPage("GAMES");else if(name.equals("Tools"))showPage("TOOLS");else new AlertDialog.Builder(this).setTitle(name).setMessage("Pengaturan " + name + " masih berupa fitur dasar. Tidak ada overclock atau perubahan sistem otomatis.").setPositiveButton("OK",null).show();}); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(70),1); lp.setMargins(0,0,dp(8),dp(8)); r.addView(tile,lp);} quick.addView(r); }
        content.addView(quick);
    }
    private int getBatteryPercent(){ try { Intent i=registerReceiver(null,new IntentFilter(Intent.ACTION_BATTERY_CHANGED)); if(i==null)return 0; int level=i.getIntExtra("level",-1), scale=i.getIntExtra("scale",-1); return level>=0&&scale>0?Math.round(level*100f/scale):0; } catch(Exception e){ return 0; } }

    private void metric(LinearLayout row,String label,String value){LinearLayout box=column();box.setBackground(shape(PANEL,14));pad(box,12,12,8,12);box.addView(text(label,9,MUTED,true));gap(box,5);box.addView(text(value,13,WHITE,true));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(76),1);lp.setMargins(0,0,dp(7),0);row.addView(box,lp);}

    private List<ResolveInfo> getLaunchableApps() {
        Intent intent=new Intent(Intent.ACTION_MAIN); intent.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> list=getPackageManager().queryIntentActivities(intent,0);
        Collections.sort(list,new Comparator<ResolveInfo>(){public int compare(ResolveInfo a,ResolveInfo b){return String.valueOf(a.loadLabel(getPackageManager())).compareToIgnoreCase(String.valueOf(b.loadLabel(getPackageManager())));}});
        return list;
    }
    private void games() {
        content.addView(text("GAME SPACE",26,WHITE,true)); gap(content,4); content.addView(text("Pusat akses aplikasi dan game di perangkat ini",13,MUTED,false)); gap(content,16);
        LinearLayout intro=column(); intro.setBackground(shape(Color.rgb(46,18,24),18)); pad(intro,16,15,16,15); intro.addView(text("PLAY HUB",10,RED,true)); gap(intro,6); intro.addView(text("Pilih aplikasi atau game untuk langsung membukanya.",14,WHITE,true)); card(content,intro);
        List<ResolveInfo> apps=getLaunchableApps(); int count=0;
        for(ResolveInfo ri:apps){String label=String.valueOf(ri.loadLabel(getPackageManager())); if(label.equals(getString(R.string.app_name))) continue;
            LinearLayout item=row(); item.setBackground(shape(PANEL,15)); pad(item,12,10,12,10);
            TextView icon=text("▣",23,RED,true); icon.setGravity(Gravity.CENTER); item.addView(icon,new LinearLayout.LayoutParams(dp(48),dp(48)));
            LinearLayout names=column(); names.addView(text(label,14,WHITE,true)); names.addView(text(ri.activityInfo.packageName,9,MUTED,false)); LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(0,-2,1); np.leftMargin=dp(8); item.addView(names,np);
            Button launch=button("MAIN"); launch.setTextSize(11); launch.setMinWidth(dp(64)); launch.setOnClickListener(v->{try{Intent launchIntent=getPackageManager().getLaunchIntentForPackage(ri.activityInfo.packageName);if(launchIntent!=null)startActivity(launchIntent);else Toast.makeText(this,"Game tidak bisa dibuka dari launcher",Toast.LENGTH_SHORT).show();}catch(Exception e){Toast.makeText(this,"Tidak dapat membuka aplikasi",Toast.LENGTH_SHORT).show();}}); item.addView(launch);
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.bottomMargin=dp(8); content.addView(item,lp); count++;
        }
        if(count==0){gap(content,12);content.addView(text("Belum ada aplikasi yang dapat ditampilkan.",13,MUTED,false));}
        gap(content,10); Button refresh=button("MUAT ULANG DAFTAR GAME"); refresh.setOnClickListener(v->showPage("GAMES")); content.addView(refresh,new LinearLayout.LayoutParams(-1,dp(48)));
    }
    private void tools() {
        content.addView(text("KENZOS TOOLS",25,WHITE,true)); gap(content,5); content.addView(text("Pintasan praktis perangkat",13,MUTED,false)); gap(content,18);
        tool("⚙","Pengaturan Android","Buka pengaturan perangkat",()->startActivity(new Intent(Settings.ACTION_SETTINGS)));
        tool("▤","Info aplikasi","Kelola izin dan penyimpanan launcher",()->{try{startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:"+getPackageName())));}catch(Exception e){}});
        tool("🎮","Game Space","Kelola dan buka aplikasi game",()->showPage("GAMES"));
        tool("◐","Wallpaper","Ubah wallpaper melalui pengaturan perangkat",()->{try{startActivity(new Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER));}catch(Exception e){startActivity(new Intent(Settings.ACTION_DISPLAY_SETTINGS));}});
        LinearLayout note=column();note.setBackground(shape(PANEL,16));pad(note,14,14,14,14);note.addView(text("CATATAN",10,RED,true));gap(note,6);note.addView(text("KENZOS Launcher adalah aplikasi Home pihak ketiga. RAM dan baterai ditampilkan sebagai informasi perangkat. Aplikasi ini tidak melakukan overclock CPU, mengubah FPS sistem, atau menjanjikan peningkatan performa otomatis.",12,MUTED,false));card(content,note);
    }
    private void tool(String icon,String title,String subtitle,Runnable action){LinearLayout item=row();item.setBackground(shape(PANEL,16));pad(item,14,13,14,13);TextView ico=text(icon,22,RED,true);ico.setGravity(Gravity.CENTER);item.addView(ico,new LinearLayout.LayoutParams(dp(42),dp(42)));LinearLayout info=column();info.addView(text(title,14,WHITE,true));info.addView(text(subtitle,11,MUTED,false));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1);lp.leftMargin=dp(10);item.addView(info,lp);item.addView(text("›",24,MUTED,false));item.setOnClickListener(v->action.run());LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=dp(10);content.addView(item,p);}
}
