# KENZOS Launcher — OPPO A15s / Android 10

Source project Android Studio untuk launcher Android bertema gaming gelap dengan aksen merah. Disiapkan dengan `minSdk 26` dan `targetSdk 29` untuk kompatibilitas perilaku aplikasi yang lebih dekat ke Android 10.

## Fitur yang tersedia
- Home dashboard bertema KENZOS.
- Game Space / daftar aplikasi yang dapat diluncurkan, dengan tombol buka langsung.
- Snapshot baterai dan RAM (informasi sistem; bukan pengukur FPS).
- Pintasan ke Pengaturan Android dan informasi aplikasi.
- Dapat dipilih sebagai aplikasi Home/default launcher.
- Tidak memerlukan akses root.

## Build APK
1. Instal Android Studio versi terbaru dan Android SDK Platform 35.
2. Ekstrak ZIP, lalu buka folder `KenzOSLauncher` di Android Studio.
3. Tunggu Gradle Sync selesai. Pastikan komputer tersambung internet saat Gradle mengunduh plugin yang diperlukan.
4. Pilih **Build > Build APK(s)**.
5. APK debug biasanya berada di `app/build/outputs/apk/debug/app-debug.apk`.
6. Pindahkan APK ke OPPO A15s dan instal. Jika diminta, izinkan pemasangan aplikasi dari sumber tersebut.
7. Tekan tombol Home, pilih **KENZOS Launcher**, lalu pilih **Selalu**. Jika tidak muncul, buka Pengaturan > Manajemen Aplikasi / Aplikasi Default > Aplikasi Home (nama menu dapat berbeda pada ColorOS).

## Detail proyek
- Package: `com.kenzphone.kenzoslauncher`
- Minimum Android: 8.0 (API 26); target Android 10 (API 29).
- Bahasa: Java; UI dibangun secara native tanpa library UI eksternal.

## Batasan yang jujur
Ini source project, belum APK yang dikompilasi atau diuji langsung pada OPPO A15s. Game Space menampilkan aplikasi yang terdaftar untuk dibuka dari launcher, tidak selalu hanya game. Informasi RAM/baterai bersifat snapshot. Fitur seperti pengaturan GPU, overclock, peningkatan FPS paksa, atau pembatasan aplikasi latar sistem tidak tersedia dan tidak diklaim berjalan.
